##############################################################
# Services & Apps Template
# env zero Workflows MasterClass Demo
#
# The final layer in the workflow stack.
# Receives cluster_endpoint + cluster_name from EKS,
# and db_endpoint from the database sub-environment.
#
# Deploys a Kubernetes namespace and a configmap that wires
# the app config together — db endpoint, cluster details, replica count.
#
# CD DEMO FIELD: change `app_replica_count` to trigger a visible diff
# in the Terraform plan when demonstrating continuous deployment.
##############################################################

terraform {
  required_version = ">= 1.3.0"
  required_providers {
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.27"
    }
  }
}

# ── Variables ─────────────────────────────────────────────────────────────
# cluster_endpoint and cluster_name come from the EKS sub-environment.
# db_endpoint comes from the database sub-environment.
# All three are wired via env zero variable passing at the workflow template level.

variable "environment_name" {
  description = "Name tag applied to all resources"
  type        = string
  default     = "demo"
}

# Passed from EKS sub-environment via env zero variable passing
variable "cluster_endpoint" {
  description = "EKS API server endpoint — received from eks sub-environment output"
  type        = string
}

variable "cluster_name" {
  description = "EKS cluster name — received from eks sub-environment output"
  type        = string
}

# Passed from database sub-environment via env zero variable passing
variable "db_endpoint" {
  description = "RDS database endpoint — received from database sub-environment output"
  type        = string
}

# ── CD DEMO VARIABLE ──────────────────────────────────────────────────────
# This is the field to change in the demo to show how a code change
# propagates through the workflow via continuous deployment.
# Change it from 2 to 3 (or any value) in the template code,
# open a PR, and show the plan diff appear across the workflow.

variable "app_replica_count" {
  description = "Number of replicas for the app deployment — change this to trigger a CD diff"
  type        = number
  default     = 2
}

variable "app_version" {
  description = "App container image tag to deploy"
  type        = string
  default     = "v1.0.0"
}

# ── Kubernetes Provider ───────────────────────────────────────────────────

provider "kubernetes" {
  host = var.cluster_endpoint

  exec {
    api_version = "client.authentication.k8s.io/v1beta1"
    command     = "aws"
    args        = ["eks", "get-token", "--cluster-name", var.cluster_name]
  }
}

# ── Namespace ─────────────────────────────────────────────────────────────

resource "kubernetes_namespace" "app" {
  metadata {
    name = var.environment_name
    labels = {
      environment = var.environment_name
      managed-by  = "env0"
    }
  }
}

# ── App Config Map ────────────────────────────────────────────────────────
# This ConfigMap wires together the outputs from upstream sub-environments.
# It makes the variable passing tangible and visible in the demo.

resource "kubernetes_config_map" "app_config" {
  metadata {
    name      = "app-config"
    namespace = kubernetes_namespace.app.metadata[0].name
  }

  data = {
    # These values were injected by env zero from upstream sub-env outputs
    DATABASE_HOST     = var.db_endpoint
    CLUSTER_ENDPOINT  = var.cluster_endpoint
    CLUSTER_NAME      = var.cluster_name
    ENVIRONMENT       = var.environment_name
    APP_VERSION       = var.app_version

    # This is the CD demo field — changing it creates a visible plan diff
    REPLICA_COUNT     = tostring(var.app_replica_count)
  }
}

# ── Outputs ───────────────────────────────────────────────────────────────

output "namespace" {
  description = "Kubernetes namespace the app is deployed into"
  value       = kubernetes_namespace.app.metadata[0].name
}

output "app_version" {
  description = "Version of the app currently deployed"
  value       = var.app_version
}

output "replica_count" {
  description = "Number of replicas currently configured"
  value       = var.app_replica_count
}
