##############################################################
# Database Template (RDS PostgreSQL)
# env zero Workflows MasterClass Demo
#
# Receives vpc_id and private_subnet_id from the VPC template
# via env zero Environment Outputs / variable passing.
# Outputs db_endpoint which the services template consumes.
##############################################################

terraform {
  required_version = ">= 1.3.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

# ── Variables ─────────────────────────────────────────────────────────────
# vpc_id and private_subnet_id come from the VPC sub-environment output.
# In env zero: Workflow Template > Variables > type=Environment Output
#   vpc_id         <- source alias: vpc, output: vpc_id
#   private_subnet_id <- source alias: vpc, output: private_subnet_id

variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "environment_name" {
  description = "Name tag applied to all resources"
  type        = string
  default     = "demo"
}

# Passed in from the VPC template via env zero variable passing
variable "vpc_id" {
  description = "VPC ID — received from vpc sub-environment output"
  type        = string
}

variable "private_subnet_id" {
  description = "Private subnet ID — received from vpc sub-environment output"
  type        = string
}

variable "db_name" {
  description = "Name of the PostgreSQL database to create"
  type        = string
  default     = "appdb"
}

variable "db_instance_class" {
  description = "RDS instance type"
  type        = string
  default     = "db.t3.micro"
}

# ── Security Group ────────────────────────────────────────────────────────

resource "aws_security_group" "rds" {
  name        = "${var.environment_name}-rds-sg"
  description = "Allow PostgreSQL access from within the VPC"
  vpc_id      = var.vpc_id

  ingress {
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name        = "${var.environment_name}-rds-sg"
    Environment = var.environment_name
    ManagedBy   = "env0"
  }
}

# ── RDS Subnet Group ──────────────────────────────────────────────────────

resource "aws_db_subnet_group" "main" {
  name       = "${var.environment_name}-db-subnet-group"
  subnet_ids = [var.private_subnet_id]

  tags = {
    Name        = "${var.environment_name}-db-subnet-group"
    Environment = var.environment_name
  }
}

# ── RDS Instance ──────────────────────────────────────────────────────────

resource "aws_db_instance" "main" {
  identifier           = "${var.environment_name}-postgres"
  engine               = "postgres"
  engine_version       = "15.3"
  instance_class       = var.db_instance_class
  allocated_storage    = 20
  db_name              = var.db_name
  username             = "dbadmin"
  password             = "CHANGE_ME_use_secrets_manager"
  skip_final_snapshot  = true
  publicly_accessible  = false
  db_subnet_group_name = aws_db_subnet_group.main.name
  vpc_security_group_ids = [aws_security_group.rds.id]

  tags = {
    Name        = "${var.environment_name}-postgres"
    Environment = var.environment_name
    ManagedBy   = "env0"
  }
}

# ── Outputs ───────────────────────────────────────────────────────────────
# db_endpoint is consumed by the services template via variable passing.
# In env zero: Workflow Template > Variables > Environment Output
#   Source alias : database
#   Output name  : db_endpoint

output "db_endpoint" {
  description = "RDS endpoint — consumed by the services template"
  value       = aws_db_instance.main.endpoint
}

output "db_name" {
  description = "Database name"
  value       = aws_db_instance.main.db_name
}
