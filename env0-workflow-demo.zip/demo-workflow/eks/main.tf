##############################################################
# EKS Cluster Template
# env zero Workflows MasterClass Demo
#
# Receives vpc_id and public_subnet_id from the VPC template.
# Outputs cluster_endpoint and cluster_name which the
# services template consumes for its Kubernetes deployment.
##############################################################

terraform {
  required_version = ">= 1.3.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

# ── Variables ─────────────────────────────────────────────────────────────
# vpc_id and public_subnet_id come from the VPC sub-environment output.
# In env zero: Workflow Template > Variables > type=Environment Output
#   vpc_id           <- source alias: vpc, output: vpc_id
#   public_subnet_id <- source alias: vpc, output: public_subnet_id

variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "environment_name" {
  description = "Name tag applied to all resources"
  type        = string
  default     = "demo"
}

# Passed in from the VPC template via env zero variable passing
variable "vpc_id" {
  description = "VPC ID — received from vpc sub-environment output"
  type        = string
}

variable "public_subnet_id" {
  description = "Public subnet ID — received from vpc sub-environment output"
  type        = string
}

variable "kubernetes_version" {
  description = "Kubernetes version for the EKS cluster"
  type        = string
  default     = "1.29"
}

variable "node_instance_type" {
  description = "EC2 instance type for EKS worker nodes"
  type        = string
  default     = "t3.medium"
}

variable "desired_node_count" {
  description = "Desired number of worker nodes — change this to trigger a CD diff in the demo"
  type        = number
  default     = 2
}

# ── IAM Roles ─────────────────────────────────────────────────────────────

resource "aws_iam_role" "eks_cluster" {
  name = "${var.environment_name}-eks-cluster-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "eks.amazonaws.com" }
    }]
  })

  tags = { Environment = var.environment_name, ManagedBy = "env0" }
}

resource "aws_iam_role_policy_attachment" "eks_cluster_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSClusterPolicy"
  role       = aws_iam_role.eks_cluster.name
}

resource "aws_iam_role" "eks_nodes" {
  name = "${var.environment_name}-eks-node-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "ec2.amazonaws.com" }
    }]
  })

  tags = { Environment = var.environment_name, ManagedBy = "env0" }
}

resource "aws_iam_role_policy_attachment" "eks_worker_node_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy"
  role       = aws_iam_role.eks_nodes.name
}

resource "aws_iam_role_policy_attachment" "eks_cni_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy"
  role       = aws_iam_role.eks_nodes.name
}

# ── EKS Cluster ───────────────────────────────────────────────────────────

resource "aws_eks_cluster" "main" {
  name     = "${var.environment_name}-cluster"
  version  = var.kubernetes_version
  role_arn = aws_iam_role.eks_cluster.arn

  vpc_config {
    subnet_ids = [var.public_subnet_id]
  }

  tags = {
    Name        = "${var.environment_name}-cluster"
    Environment = var.environment_name
    ManagedBy   = "env0"
  }

  depends_on = [aws_iam_role_policy_attachment.eks_cluster_policy]
}

# ── Node Group ─────────────────────────────────────────────────────────────

resource "aws_eks_node_group" "main" {
  cluster_name    = aws_eks_cluster.main.name
  node_group_name = "${var.environment_name}-nodes"
  node_role_arn   = aws_iam_role.eks_nodes.arn
  subnet_ids      = [var.public_subnet_id]
  instance_types  = [var.node_instance_type]

  scaling_config {
    desired_size = var.desired_node_count
    min_size     = 1
    max_size     = 5
  }

  tags = {
    Name        = "${var.environment_name}-nodes"
    Environment = var.environment_name
    ManagedBy   = "env0"
  }

  depends_on = [
    aws_iam_role_policy_attachment.eks_worker_node_policy,
    aws_iam_role_policy_attachment.eks_cni_policy,
  ]
}

# ── Outputs ───────────────────────────────────────────────────────────────
# cluster_endpoint and cluster_name are consumed by the services template.
# In env zero: Workflow Template > Variables > Environment Output
#   Source alias : eks
#   Output name  : cluster_endpoint
#   Output name  : cluster_name

output "cluster_endpoint" {
  description = "EKS API server endpoint — consumed by the services template"
  value       = aws_eks_cluster.main.endpoint
}

output "cluster_name" {
  description = "EKS cluster name — consumed by the services template"
  value       = aws_eks_cluster.main.name
}

output "cluster_version" {
  description = "Kubernetes version running on the cluster"
  value       = aws_eks_cluster.main.version
}
