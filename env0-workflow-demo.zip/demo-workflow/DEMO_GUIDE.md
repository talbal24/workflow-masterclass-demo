# env zero Workflows MasterClass — Demo Setup Guide

Complete step-by-step instructions to set up and run the live demo.

---

## What You're Building

A four-layer AWS stack deployed as a single env zero Workflow:

```
[VPC]
  ├── outputs: vpc_id, private_subnet_id, public_subnet_id
  │
  ├──> [Database (RDS)]   needs: vpc     → outputs: db_endpoint
  └──> [EKS Cluster]      needs: vpc     → outputs: cluster_endpoint, cluster_name
                │
                └──> [Services & Apps]   needs: database + eks
                     consumes: db_endpoint, cluster_endpoint, cluster_name
```

---

## Step 1 — Push Templates to GitHub

Create **one repo** (e.g. `env0-workflow-demo`) with this folder structure:

```
env0-workflow-demo/
├── env0.workflow.yml       ← the workflow file
├── vpc/
│   └── main.tf
├── database/
│   └── main.tf
├── eks/
│   └── main.tf
└── services/
    └── main.tf
```

Push everything to `main`.

---

## Step 2 — Create the 4 Templates in env zero

Create these templates in order. All are Terraform type, all point to the same repo.

| Template name     | Path in repo  | Type      |
|-------------------|---------------|-----------|
| `demo-vpc`        | `vpc/`        | Terraform |
| `demo-database`   | `database/`   | Terraform |
| `demo-eks`        | `eks/`        | Terraform |
| `demo-services`   | `services/`   | Terraform |

> Template names must match exactly what is in `env0.workflow.yml` under `templateName`.

---

## Step 3 — Enable Environment Outputs on the Project

1. Go to the Project → **Settings** → **Policies**
2. Check **Environment Outputs** and save

This must be done before variable passing will work.

---

## Step 4 — Create the Workflow Template

1. New Template → select type **env zero Workflow**
2. Name it `demo-workflow`
3. Point it to the same repo, path: `/` (root, where `env0.workflow.yml` lives)
4. Branch: `main`
5. Save

---

## Step 5 — Configure Variable Passing

Open the `demo-workflow` template → **Edit** → go to the **Variables** step.

Wire these connections one by one:

### Sub-environment: `database`
| Variable key       | Type               | Source alias | Output name        |
|--------------------|--------------------|--------------|--------------------|
| `vpc_id`           | Environment Output | `vpc`        | `vpc_id`           |
| `private_subnet_id`| Environment Output | `vpc`        | `private_subnet_id`|

### Sub-environment: `eks`
| Variable key       | Type               | Source alias | Output name        |
|--------------------|--------------------|--------------|--------------------|
| `vpc_id`           | Environment Output | `vpc`        | `vpc_id`           |
| `public_subnet_id` | Environment Output | `vpc`        | `public_subnet_id` |

### Sub-environment: `services`
| Variable key       | Type               | Source alias | Output name        |
|--------------------|--------------------|--------------|--------------------|
| `db_endpoint`      | Environment Output | `database`   | `db_endpoint`      |
| `cluster_endpoint` | Environment Output | `eks`        | `cluster_endpoint` |
| `cluster_name`     | Environment Output | `eks`        | `cluster_name`     |

> On the first deployment, the outputs won't exist yet — use **free-type** to enter the
> output names manually. env zero will resolve them at runtime because `needs` ensures
> the source sub-env deploys before the consumer.

---

## Step 6 — Deploy and Show Demo 1 (Full-Stack Deploy)

1. Create a new Environment from `demo-workflow`
2. Name it `masterclass-demo`
3. Hit **Deploy**
4. Watch the deployment timeline:
   - `vpc` starts immediately
   - `database` and `eks` start in parallel once `vpc` succeeds
   - `services` waits until both `database` and `eks` are green
5. Point out: one button, four environments, correct order, no manual coordination

**What to say:**  
*"This is a four-layer stack. I didn't have to tell env zero the order. I just described what depends on what in the YAML, and it figured out the rest."*

---

## Demo 2 — Variable Passing

After the first deployment succeeds:

1. In the env zero UI, open the `services` sub-environment
2. Go to its **Variables** tab
3. Show `db_endpoint`, `cluster_endpoint`, `cluster_name` all populated with real values
4. Explain: *"These came directly from the Terraform outputs of the database and EKS runs. No copy-paste, no manual entry. env zero captured the output, stored it, and injected it into this sub-environment automatically."*

**Good moment to highlight:**  
The `app-config` ConfigMap in the services template materialises all three values — it's a concrete, visible artefact of the variable passing. If you have kubectl access, run:

```bash
kubectl get configmap app-config -n demo -o yaml
```

to show `DATABASE_HOST`, `CLUSTER_ENDPOINT`, and `CLUSTER_NAME` all populated.

---

## Demo 3 — CD in a Workflow (PR Plan)

This is the "change the field and show the diff" demo.

### The field to change

In `services/main.tf`, find the variable `app_replica_count`:

```hcl
variable "app_replica_count" {
  description = "Number of replicas — change this to trigger a CD diff"
  type        = number
  default     = 2      # <-- change this to 3
}
```

### Steps

1. Create a new branch: `git checkout -b demo/scale-up`
2. Change `default = 2` to `default = 3`
3. Push and open a Pull Request against `main`
4. env zero detects the PR and runs `terraform plan` on the **services** sub-environment
5. The plan diff shows `REPLICA_COUNT` changing from `"2"` to `"3"` in the ConfigMap
6. Results post back to the PR as a comment

**What to say:**  
*"I just changed one variable in one file. env zero saw the PR, ran a plan on the affected sub-environment, and posted the diff right here in GitHub — before anything is deployed. The team can review the change in the PR, and I can merge knowing exactly what will happen."*

**Optional:** After showing the plan, merge the PR and show env zero auto-deploying the change via continuous deployment.

---

## Quick Reference — Variable Passing Summary

```
vpc.vpc_id              ──> database.vpc_id
vpc.vpc_id              ──> eks.vpc_id
vpc.private_subnet_id   ──> database.private_subnet_id
vpc.public_subnet_id    ──> eks.public_subnet_id
database.db_endpoint    ──> services.db_endpoint
eks.cluster_endpoint    ──> services.cluster_endpoint
eks.cluster_name        ──> services.cluster_name
```

---

## Common Questions to Expect

**"What if the VPC already exists? Do I have to deploy through the workflow?"**  
No — you can use the `vcs` block inline in the workflow YAML instead of a `templateName`, or point to an existing environment's outputs using a cross-environment output (any deployed env in the org can be a source, not just sub-envs in the same workflow).

**"What if the EKS deploy fails — does the services deploy still run?"**  
No. The `needs` field is a hard gate. If any dependency fails, all downstream sub-environments are skipped. The workflow stops cleanly.

**"Can I run just one sub-environment without running the whole workflow?"**  
Yes — partial deployment. You can select individual sub-environments to redeploy from the workflow environment page.

**"Can I disable a sub-environment without deleting it from the YAML?"**  
Yes — set `disabled: true` or `disabled: ${SOME_VARIABLE}` and the sub-environment is skipped on that deployment run.
