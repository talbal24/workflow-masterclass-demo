##############################################################
# VPC Template
# env zero Workflows MasterClass Demo
#
# Creates a simple VPC with public + private subnets.
# Outputs vpc_id and subnet_id — these get passed downstream
# to the database and EKS templates via variable passing.
##############################################################

terraform {
  required_version = ">= 1.3.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

# ── Variables ─────────────────────────────────────────────────────────────

variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "us-east-1"
}

variable "environment_name" {
  description = "Name tag applied to all resources (e.g. staging, prod)"
  type        = string
  default     = "demo"
}

variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
  default     = "10.0.0.0/16"
}

# ── VPC ──────────────────────────────────────────────────────────────────

resource "aws_vpc" "main" {
  cidr_block           = var.vpc_cidr
  enable_dns_support   = true
  enable_dns_hostnames = true

  tags = {
    Name        = "${var.environment_name}-vpc"
    Environment = var.environment_name
    ManagedBy   = "env0"
  }
}

# ── Subnets ───────────────────────────────────────────────────────────────

resource "aws_subnet" "public" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = cidrsubnet(var.vpc_cidr, 8, 1)
  availability_zone       = "${var.aws_region}a"
  map_public_ip_on_launch = true

  tags = {
    Name        = "${var.environment_name}-public-subnet"
    Environment = var.environment_name
    Tier        = "public"
  }
}

resource "aws_subnet" "private" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = cidrsubnet(var.vpc_cidr, 8, 2)
  availability_zone = "${var.aws_region}b"

  tags = {
    Name        = "${var.environment_name}-private-subnet"
    Environment = var.environment_name
    Tier        = "private"
  }
}

# ── Internet Gateway ──────────────────────────────────────────────────────

resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id

  tags = {
    Name        = "${var.environment_name}-igw"
    Environment = var.environment_name
  }
}

# ── Outputs ───────────────────────────────────────────────────────────────
# These are the values that downstream sub-environments will consume.
# In env zero: Workflow Template > Variables > Environment Output
#   Source alias : vpc
#   Output name  : vpc_id  (feeds into database + eks templates)
#   Output name  : private_subnet_id (feeds into database template)
#   Output name  : public_subnet_id  (feeds into eks + services templates)

output "vpc_id" {
  description = "ID of the VPC — consumed by database and EKS templates"
  value       = aws_vpc.main.id
}

output "private_subnet_id" {
  description = "ID of the private subnet — consumed by the database template"
  value       = aws_subnet.private.id
}

output "public_subnet_id" {
  description = "ID of the public subnet — consumed by EKS and services templates"
  value       = aws_subnet.public.id
}

output "vpc_cidr" {
  description = "CIDR block of the VPC"
  value       = aws_vpc.main.cidr_block
}
